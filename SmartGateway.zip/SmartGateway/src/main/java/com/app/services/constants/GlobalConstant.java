/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.services.constants;

import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author Saeed Fathi
 */
public class GlobalConstant {

    public static final String customerAuthority = "customer";
    public static final String serviceConsumerRole = "Serivces_Consumers";
    public static final String g2gUser = "G2GMOSS";
    public static final int CREATE_NEW_ACCOUNT = 1;
    public static final int FORGET_PASSWORD = 2;
    public static final int CITIZEN = 52;
    public static final int GROCER = 51;
    public static final int CITIZEN_ROLE = 11;
    public static final int GROCER_ROLE = 10;
    public static Set<Integer> serviceOtpID = new HashSet<>();
    public static Set<Integer> userType = new HashSet<>();
    public static Map<Integer,Integer> userRoles = new HashMap<>();

    static {
        serviceOtpID.add(CREATE_NEW_ACCOUNT);
        serviceOtpID.add(FORGET_PASSWORD);
        userType.add(CITIZEN);
        userType.add(GROCER);
        userRoles.put(CITIZEN,CITIZEN_ROLE);
        userRoles.put(GROCER,GROCER_ROLE);
    }
    private GlobalConstant() {
    }

}
