package com.app.services.constants;

public class ServiceName {
    public static final String SEND_OTP_TO_MOB = "send-otp";
    public static final String VALIDATE_OTP = "validate-otp";
    public static final String CREATE_ACCOUNT = "create-account";
    public static final String FORGET_PASSWORD = "forget-password";

}
