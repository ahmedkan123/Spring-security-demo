package com.app.services.entity;

public class OtpResponse extends Response{
    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public OtpResponse(Integer responseCode) {
        super(responseCode);
    }
    public OtpResponse(Integer responseCode,String token) {
        super(responseCode);
        this.token = token;
    }
}
