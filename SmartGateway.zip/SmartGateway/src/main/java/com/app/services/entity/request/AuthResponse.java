/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.services.entity.request;

import com.app.services.entity.Response;

/**
 *
 * @author Saeed Fathi
 */
public class AuthResponse extends Response {

    private String token;
    private String category;
    private String name;

    public AuthResponse() {
    }

    public AuthResponse(Integer responseCode) {
        super(responseCode);
    }

    public AuthResponse(String token, Integer responseCode) {
        super(responseCode);
        this.token = token;
    }

    public AuthResponse(String token, Integer responseCode, String responseMsg) {
        super(responseCode, responseMsg);
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
