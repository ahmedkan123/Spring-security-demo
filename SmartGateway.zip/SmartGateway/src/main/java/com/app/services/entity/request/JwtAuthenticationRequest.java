/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.app.services.entity.request;

import com.app.services.constants.ResponseCodes;
import javax.validation.constraints.NotBlank;

/**
 *
 * @author Saeed
 */
public class JwtAuthenticationRequest {

    private static final long serialVersionUID = -8445943548965154778L;

    @NotBlank(message = ResponseCodes.usernameIncorrect)
    private String username;

    @NotBlank(message = ResponseCodes.passwordIncorrect)
    private String password;
    private short roleID;

//    @NotBlank(message = ResponseCodes.POS_NOT_EXIST)
//    private String posSerial;

    public JwtAuthenticationRequest() {
        super();
    }

    public JwtAuthenticationRequest(String username, String password) {
        this.setUsername(username);
        this.setPassword(password);
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    public String getPosSerial() {
//        return posSerial;
//    }
//
//    public void setPosSerial(String posSerial) {
//        this.posSerial = posSerial;
//    }

    public short getRoleID() {
        return roleID;
    }

    public void setRoleID(short roleID) {
        this.roleID = roleID;
    }

    public JwtAuthenticationRequest(String username, String password, short roleID) {
        this.username = username;
        this.password = password;
        this.roleID = roleID;
    }
}
