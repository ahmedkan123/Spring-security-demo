package com.app.services.security.basic;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Clock;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.DefaultClock;
import java.io.Serializable;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;

@Component
public class BasicTokenUtil implements Serializable {

    static final String CLAIM_KEY_USERNAME = "sub";
    static final String CLAIM_KEY_CREATED = "iat";
    private static final long serialVersionUID = -3301605591108950415L;
    //   @SuppressFBWarnings(value = "SE_BAD_FIELD", justification = "It's okay here")
    private Clock clock = DefaultClock.INSTANCE;

    @Value("${jwt.secret}")
    private String secret = "SmartCloudSecret";

    @Value("${jwt.expiration}")
    private Long expiration;

    public String getUsernameFromToken(String token) {
        return getClaimFromToken(token, Claims::getSubject);
    }

    public Date getIssuedAtDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getIssuedAt);
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public Integer getAppType(String token) {
        Claims claims = getAllClaimsFromToken(token);
        return claims.get("appType", Integer.class);
    }

    public String getUserAuthority(String token) {
        Claims claims = getAllClaimsFromToken(token);
        return claims.get("scopes", List.class).get(0).toString();
    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    public Claims getAllClaimsFromToken(String token) {
        token = token.replace("Bearer ", "");
        return Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token)
                .getBody();
    }

    public boolean isTokenExpired(String token) {
        try{
            final Date expiration = getExpirationDateFromToken(token);
            return expiration.before(clock.now());
        }catch (Exception e){
            return true;
        }

    }

    private Boolean isCreatedBeforeLastPasswordReset(Date created, Date lastPasswordReset) {
        return (lastPasswordReset != null && created.before(lastPasswordReset));
    }

    private Boolean ignoreTokenExpiration(String token) {
        // here you specify tokens, for that the expiration is ignored
        return false;
    }

    public String generateToken(BasicUser userDetails) {
        Map<String, Object> claims = new HashMap<>();
//        claims.put("appType", appType);
        claims.put("scopes", userDetails.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));
        claims.put("roleID",userDetails.getRole().getId());
        return doGenerateToken(claims, userDetails.getUsername());
    }

    private String doGenerateToken(Map<String, Object> claims, String subject) {
        final Date createdDate = clock.now();
        final Date expirationDate = calculateExpirationDate(createdDate);

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(createdDate)
                .setExpiration(expirationDate)
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    private String generateToken(Map<String, Object> claims){
        final Date createdDate = clock.now();
        return Jwts.builder()
                .setClaims(claims)
                .setSubject("OTP")
                .setIssuedAt(createdDate)
                .setExpiration(new Date(createdDate.getTime() + 5 * 60 * 1000))
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    public String getToken(String mobNo,int serviceId,String userName,int userType,String otp){
        Map<String, Object> claims = new HashMap<>();
        claims.put("mobNo", mobNo);
        claims.put("serviceId", serviceId);
        claims.put("userName", userName);
        claims.put("userType", userType);
        claims.put("otp", otp);
        return generateToken(claims);
    }
    public String getToken(Claims claims,boolean validated,int serviceId,String userName,int userType){
        claims.clear();
        claims.put("validated", validated);
        claims.put("serviceId", serviceId);
        claims.put("userName", userName);
        claims.put("userType", userType);
        return generateToken(claims);
    }

    public Boolean canTokenBeRefreshed(String token, Date lastPasswordReset) {
        final Date created = getIssuedAtDateFromToken(token);
        return !isCreatedBeforeLastPasswordReset(created, lastPasswordReset)
                && (!isTokenExpired(token) || ignoreTokenExpiration(token));
    }

    public String refreshToken(String token) {
        final Date createdDate = clock.now();
        final Date expirationDate = calculateExpirationDate(createdDate);

        final Claims claims = getAllClaimsFromToken(token);
        claims.setIssuedAt(createdDate);
        claims.setExpiration(expirationDate);

        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    public String refreshStaticToken(String token) {
        final Date createdDate = clock.now();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, 10);
        Date nextYear = cal.getTime();
        final Date expirationDate = nextYear;

        final Claims claims = getAllClaimsFromToken(token);
        claims.setIssuedAt(createdDate);
        claims.setExpiration(expirationDate);

        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS512, secret)
                .compact();
    }

    public Boolean validateToken(String token, UserDetails userDetails) {
        BasicUser user = (BasicUser) userDetails;
        final String username = getUsernameFromToken(token);
        final Date created = getIssuedAtDateFromToken(token);
        //final Date expiration = getExpirationDateFromToken(token);
        return (username.equals(user.getUsername())
                && !isTokenExpired(token) //                && !isCreatedBeforeLastPasswordReset(created, user.get())
                );
    }

    private Date calculateExpirationDate(Date createdDate) {
        return new Date(createdDate.getTime() + 1440 * 60 * 1000); // 10 m
    }

    public String getUsernameFromBasicToken(String token) {
        byte[] credDecoded = Base64.getDecoder().decode(token);
        String credentials = new String(credDecoded, StandardCharsets.UTF_8);
        int seperatorIndex = credentials.indexOf(':');
        return credentials.substring(0, seperatorIndex);
    }

    public String getPasswordFromBasicToken(String token) {
        byte[] credDecoded = Base64.getDecoder().decode(token);
        String credentials = new String(credDecoded, StandardCharsets.UTF_8);
        int seperatorIndex = credentials.indexOf(':');
        return credentials.substring(seperatorIndex + 1);
    }

}
