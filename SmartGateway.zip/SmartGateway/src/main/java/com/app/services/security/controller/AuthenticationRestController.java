package com.app.services.security.controller;

import com.app.services.constants.ResponseCodes;
import com.app.services.entity.request.JwtAuthenticationRequest;
import com.app.services.entity.Response;
import com.app.services.entity.request.AuthResponse;
import com.app.services.entity.request.ChangePasswordRequest;
import com.app.services.security.basic.BasicTokenUtil;
import com.app.services.security.basic.BasicUser;
import com.app.services.security.service.AuthUserDetailsService;
import java.util.Objects;

import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.services.util.Utils;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;

@CrossOrigin
@RestController
@RequestMapping("/auth/")
public class AuthenticationRestController {

//    @Value("${jwt.header}")
//    private String tokenHeader;
    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private BasicTokenUtil jwtTokenUtil;
    @Autowired
    private AuthUserDetailsService authUserDetailsService;

    @PostMapping(value = "${jwt.route.authentication.path}")
    public ResponseEntity<AuthResponse> createAuthenticationToken(@RequestBody JwtAuthenticationRequest authenticationRequest) {
        AuthResponse respone = null;
        try {

            //validate
            int responseCode = Utils.validate(authenticationRequest);

            if (responseCode == ResponseCodes.success) {

                // Reload password post-security so we can generate the token
                final BasicUser userDetails = (BasicUser) authUserDetailsService.loadUserByUsernameAndRole(authenticationRequest.getUsername(), authenticationRequest.getRoleID());

                if (!userDetails.isEnabled()) {
                    return ResponseEntity.ok(new AuthResponse(ResponseCodes.disabledCredentials));
                }
                if (!userDetails.getPassword().equals(authenticationRequest.getPassword())) {
                    return ResponseEntity.ok(new AuthResponse(Integer.valueOf(ResponseCodes.passwordIncorrect)));
                }
                final String token = jwtTokenUtil.generateToken(userDetails);
                respone = new AuthResponse(ResponseCodes.success);
                respone.setToken(token);
                respone.setName(userDetails.getName());
                respone.setCategory(userDetails.getRole().getId().toString());
            } else {
                respone = new AuthResponse(responseCode);
            }

        } catch (Exception e) {
            e.printStackTrace();
            respone = new AuthResponse(ResponseCodes.badCredentials);
        }
        // Return the token
        return ResponseEntity.ok(respone);
    }

    /*
    @GetMapping(value = "${jwt.route.authentication.userdata}")
    public ResponseEntity<UserDataResponse> userdata(HttpServletRequest request) {
        UserDataResponse respone;
        try {

            List<String> services = this.discoveryClient.getServices();
            List<ServiceInstance> instances = new ArrayList<ServiceInstance>();
            services.forEach(serviceName -> {
                this.discoveryClient.getInstances(serviceName).forEach(instance -> {
                    instances.add(instance);
                    System.out.println("*******************************  : " + instance.getInstanceId());
                });
            });

            //Get token & username & authority
            String authToken = request.getHeader(tokenHeader);
            String userName = jwtTokenUtil.getUsernameFromToken(authToken);
            String authority = jwtTokenUtil.getUserAuthority(authToken);

            //initiate the client object
            FindUserRequest userRequest = new FindUserRequest();
            userRequest.setUserName(userName);

            //Check auth of the user (Customer or ..)
            if (authority.equals(GlobalConstant.customerAuthority)) {
                respone = customerClient.find(userRequest);
            } else {
                respone = new UserDataResponse(ResponseCodes.authorityNotAllowUserData);
            }

            return ResponseEntity.ok(respone);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.ok(new UserDataResponse(ResponseCodes.unHandeledException));
        }
    }

    @GetMapping(value = "${jwt.route.authentication.refresh}")
    public ResponseEntity<RefreshResponse> refreshAndGetAuthenticationToken(HttpServletRequest request) {

        try {
            String authToken = request.getHeader(tokenHeader);
            final String token = authToken.substring(7);
            String username = jwtTokenUtil.getUsernameFromToken(token);
            JwtUser user = (JwtUser) userDetailsService.loadUserByUsername(username);

            if (jwtTokenUtil.canTokenBeRefreshed(token, user.getLastPasswordResetDate())) {
                String refreshedToken = jwtTokenUtil.refreshToken(token);
                return ResponseEntity.ok(new RefreshResponse(refreshedToken, ResponseCodes.success));
            } else {
                return ResponseEntity.ok(new RefreshResponse(ResponseCodes.cantRefreshToken));
            }
        } catch (Exception e) {
            return ResponseEntity.ok(new RefreshResponse(ResponseCodes.unHandeledException));
        }
    }
     */
    @PostMapping(value = "${jwt.route.authentication.changePassword}")
    public ResponseEntity<Response> changePassword(@RequestBody ChangePasswordRequest passwordRequest, HttpServletRequest request, @Value("${jwt.header}") String tokenHeader) {

        try {
            //Validate
            Response respone = new Response(Utils.validate(passwordRequest));

            if (respone.getResponseCode() == ResponseCodes.success) {

                //Get token & username & authority
                String authToken = request.getHeader(tokenHeader);
                String userName = jwtTokenUtil.getUsernameFromToken(authToken);

                Claims claims = jwtTokenUtil.getAllClaimsFromToken(authToken);
                int roleID = (int)claims.get("roleID");

                respone = authUserDetailsService.changePassword(passwordRequest, userName, (short) roleID);
            }

            return ResponseEntity.ok(respone);
        } catch (Exception e) {
            return ResponseEntity.ok(new Response(ResponseCodes.unHandeledException));
        }
    }

    /**
     * @PostMapping(value = "${jwt.route.authentication.forgetPassword}") public
     * ResponseEntity<Response> forgetPassword(@RequestBody
     * ForgetPasswordRequest forgetPasswordRequest) { try { Response respone =
     * customerClient.forgetPasswordRequest(forgetPasswordRequest);
     *
     * return ResponseEntity.ok(respone); } catch (Exception e) { return
     * ResponseEntity.ok(new Response(ResponseCodes.unHandeledException)); } }
     */
    @ExceptionHandler({AuthenticationException.class})
    public ResponseEntity<String> handleAuthenticationException(AuthenticationException e
    ) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
    }

    /**
     * Authenticates the user. If something is wrong, an
     * {@link AuthenticationException} will be thrown
     */
    private void authenticate(String username, String password) {
        Objects.requireNonNull(username);
        Objects.requireNonNull(password);

//        	 Generating Bcrypt Password as per Spring Security
//            BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
//            String hashedPassword = passwordEncoder.encode("userpass");
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, username + password));

    }

}
