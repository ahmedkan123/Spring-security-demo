package com.app.services.security.controller;

import com.app.services.constants.ResponseCodes;
import com.app.services.constants.ServiceName;
import com.app.services.entity.OtpResponse;
import com.app.services.entity.Response;
import com.app.services.entity.request.CreateAccountRequest;
import com.app.services.entity.request.ForgetPasswordRequest;
import com.app.services.entity.request.ValidateOTPRequest;
import com.app.services.security.repository.UserRepository;
import com.app.services.security.service.RegistrationService;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/registration/")
public class RegistrationRestController {

    @Autowired
    private RegistrationService registerService;


    //TODO delete that end point
    @DeleteMapping("delete-user-by-nid/{nid}")
    public void deleteUserByNID(@PathVariable String nid){
        try{
            registerService.deleteUserByNID(nid);
        }catch (Exception ex) { // exception
            ex.printStackTrace();
        }
    }

    @GetMapping(value = ServiceName.SEND_OTP_TO_MOB)
    public OtpResponse sendOTP(@RequestParam("serviceId") Integer serviceId,
                               @ApiParam(hidden = true) @RequestHeader(value = "sendOTPToken") String sendOTPToken) {
        OtpResponse response = null;
        try {
            response = registerService.sendOTP(sendOTPToken,serviceId);
        } catch (Exception ex) { // exception
            ex.printStackTrace();
            response = new OtpResponse(ResponseCodes.unHandeledException);
        }
        return response;
    }

    @PostMapping(value = ServiceName.VALIDATE_OTP)
    public OtpResponse validateOTP(@RequestBody ValidateOTPRequest request,
                                   @ApiParam(hidden = true) @RequestHeader(value = "validateToken") String validateToken){
        OtpResponse response = null;
        try {
            response = registerService.validateOTP(request,validateToken);
        } catch (Exception ex) { // exception
            ex.printStackTrace();
            response = new OtpResponse(ResponseCodes.unHandeledException);
        }
        return response;
    }
    @PostMapping(value = ServiceName.CREATE_ACCOUNT)
    public Response createAccount(@RequestBody CreateAccountRequest request,
                                  @ApiParam(hidden = true) @RequestHeader(value = "createAccountToken") String createAccountToken){
        Response response = null;
        try {
            response = registerService.createAccount(request,createAccountToken);
        } catch (Exception ex) { // exception
            ex.printStackTrace();
            response = new Response(ResponseCodes.unHandeledException);
        }
        return response;
    }
    @PostMapping(value = ServiceName.FORGET_PASSWORD)
    public Response forgetPassword(@RequestBody ForgetPasswordRequest request,
                                  @ApiParam(hidden = true) @RequestHeader(value = "forgetPasswordToken") String forgetPasswordToken){
        Response response = null;
        try {
            response = registerService.forgetPassword(request,forgetPasswordToken);
        } catch (Exception ex) { // exception
            ex.printStackTrace();
            response = new Response(ResponseCodes.unHandeledException);
        }
        return response;
    }
}
