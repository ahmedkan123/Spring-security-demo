package com.app.services.security.repository;

import com.app.services.model.AuthUser;
import com.app.services.model.MobOTP;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Created by stephan on 20.03.16.
 */
@Repository
public interface MobOtpRepository extends JpaRepository<MobOTP, String> {
    Optional<MobOTP> findMobOTPByMobNo(String s);
}
