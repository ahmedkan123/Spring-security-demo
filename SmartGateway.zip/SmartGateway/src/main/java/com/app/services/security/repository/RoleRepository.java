package com.app.services.security.repository;

import com.app.services.model.AuthRole;
import com.app.services.model.AuthUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by stephan on 20.03.16.
 */
@Repository
public interface RoleRepository extends JpaRepository<AuthRole, Short> {
    AuthRole findAuthRoleById(Short id);
}
