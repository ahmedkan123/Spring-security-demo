package com.app.services.security.service;

import com.app.services.constants.ResponseCodes;
import com.app.services.entity.Response;
import com.app.services.entity.request.ChangePasswordRequest;
import com.app.services.model.AuthRole;
import com.app.services.model.AuthUser;
import com.app.services.security.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.services.security.basic.BasicUserFactory;
import com.app.services.security.repository.UserRepository;

@Service
public class AuthUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AuthUser user = userRepository.findByUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException(String.format("No user found with username '%s'.", username));
        } else if (!user.getEnabled()) {
            throw new UsernameNotFoundException(String.format("User is disabled '%s'.", username));
        } else {
            return BasicUserFactory.create(user);
        }
    }
    public UserDetails loadUserByUsernameAndRole(String username,short roleID) throws UsernameNotFoundException {
        AuthRole role = roleRepository.findAuthRoleById(roleID);
        AuthUser user = userRepository.findByUsernameAndRole(username,role);

        if (user == null) {
            throw new UsernameNotFoundException(String.format("No user found with username '%s'.", username));
        } else if (!user.getEnabled()) {
            throw new UsernameNotFoundException(String.format("User is disabled '%s'.", username));
        } else {
            return BasicUserFactory.create(user);
        }
    }

    public Response changePassword(ChangePasswordRequest passwordRequest, String username, short roleID) throws UsernameNotFoundException {
        Response response = new Response(ResponseCodes.success);
        AuthRole role = roleRepository.findAuthRoleById(roleID);
        AuthUser user = userRepository.findByUsernameAndRole(username,role);

        if (user == null || !user.getEnabled()) {
            response = new Response(ResponseCodes.authorityNotAllowChangePassword);
        } else if (!user.getPassword().equals(passwordRequest.getOldPassword())) {
            response = new Response(Integer.valueOf(ResponseCodes.oldPasswordIncorrect));
        } else {
            if(passwordRequest.getNewPassword() == null || passwordRequest.getNewPassword().length() < 6)
                return new Response(ResponseCodes.INVALID_PASSWORD);

            user.setPassword(passwordRequest.getNewPassword());
            userRepository.save(user);
        }

        return response;

    }

}
