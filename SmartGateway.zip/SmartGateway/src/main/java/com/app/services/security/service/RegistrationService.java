package com.app.services.security.service;

import com.app.services.constants.GlobalConstant;
import com.app.services.constants.ResponseCodes;
import com.app.services.entity.OtpResponse;
import com.app.services.entity.Response;
import com.app.services.entity.request.CreateAccountRequest;
import com.app.services.entity.request.ForgetPasswordRequest;
import com.app.services.entity.request.ValidateOTPRequest;
import com.app.services.model.AuthRole;
import com.app.services.model.AuthService;
import com.app.services.model.AuthUser;
import com.app.services.model.MobOTP;
import com.app.services.security.basic.BasicTokenUtil;
import com.app.services.security.repository.MobOtpRepository;
import com.app.services.security.repository.RoleRepository;
import com.app.services.security.repository.ServiceRepository;
import com.app.services.security.repository.UserRepository;
import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

import static com.app.services.validation.SystemValidation.IS_MOBILE_NUMBER;
import static com.app.services.validation.SystemValidation.NATIONAL_ID_VALIDATION;

@Service
public class RegistrationService {
    @Autowired
    private MobOtpRepository mobOtpRepository;
    @Autowired
    private BasicTokenUtil basicTokenUtil;
    @Autowired
    private ServiceRepository serviceRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RoleRepository roleRepository;
    public void deleteUserByNID(String nid){
        List<AuthUser> list = userRepository.findAuthUserByUsername(nid);
        list.forEach(u-> userRepository.delete(u));
    }
    public OtpResponse sendOTP(String sendOTPToken, int serviceId) {
        if(!GlobalConstant.serviceOtpID.contains(serviceId)){
            return new OtpResponse(ResponseCodes.INVALID_SERVICE_ID);
        }

        Claims claims = basicTokenUtil.getAllClaimsFromToken(sendOTPToken);
        String mobNo = (String) claims.get("mobNo");
        String userName = (String) claims.get("userName");
        int userType = (int) claims.get("userType");

        if(serviceId==2){
            int roleID = GlobalConstant.userRoles.get(userType);
            AuthUser user = getUserByUsernameAndRoleID(userName,roleID);
            if(user==null)
                return new OtpResponse(ResponseCodes.USER_NOT_FOUND);
        }

        if(mobNo==null || !IS_MOBILE_NUMBER.test(mobNo))
            return new OtpResponse(ResponseCodes.WRONG_MOB_STRUCTURE);

        String pin = "1234";
//        MobOTP otp = new MobOTP(mobNo, pin, serviceId);
//        mobOtpRepository.save(otp);
//        smsUtilty.sendSMS(otp.getMobNo(), "رقم التفعيل : " + otp.getOtp());

        String token = basicTokenUtil.getToken(mobNo,serviceId,userName,userType,pin);

        return new OtpResponse(ResponseCodes.success,token);
    }
    public OtpResponse validateOTP(ValidateOTPRequest request, String validateToken){
        if(basicTokenUtil.isTokenExpired(validateToken)){
            return new OtpResponse(ResponseCodes.EXPIRED_TOKEN);
        }
        Claims claims = basicTokenUtil.getAllClaimsFromToken(validateToken);
        String mobNo = (String) claims.get("mobNo");
        int serviceId = (int) claims.get("serviceId");
        String userName = (String) claims.get("userName");
        int userType = (int) claims.get("userType");
        String otp = (String) claims.get("otp");

        if(!request.getOtp().equals(otp)){
            return new OtpResponse(ResponseCodes.INVALID_OTP);
        }

        String token = basicTokenUtil.getToken(claims,true,serviceId,userName,userType);

        return new OtpResponse(ResponseCodes.success,token);
    }
    public Response createAccount(CreateAccountRequest request, String createAccountToken){
        if(basicTokenUtil.isTokenExpired(createAccountToken)){
            return new Response(ResponseCodes.EXPIRED_TOKEN);
        }
        Claims claims = basicTokenUtil.getAllClaimsFromToken(createAccountToken);
        boolean validated = (boolean) claims.get("validated");
        int serviceId = (int) claims.get("serviceId");
        int userType = (int) claims.get("userType");
        if(!validated || serviceId != GlobalConstant.CREATE_NEW_ACCOUNT){
            return new OtpResponse(ResponseCodes.INVALID_TOKEN_INFO);
        }
        String password = request.getPassword();
        String nid = (String) claims.get("userName");
        if(nid==null || !NATIONAL_ID_VALIDATION.test(nid)){
            return new Response(ResponseCodes.INVALID_NATIONAL_ID);
        }
        if(password == null || password.length() < 6){
            return new Response(ResponseCodes.INVALID_PASSWORD);
        }
        if(!GlobalConstant.userType.contains(userType)){
            return new Response(ResponseCodes.INVALID_USER_TYPE);
        }

        int roleID = GlobalConstant.userRoles.get(userType);
        AuthUser user = getUserByUsernameAndRoleID(nid,roleID);
        if(user!=null)
            return new Response(ResponseCodes.USER_FOUND);

        saveUser(userType,nid,password,GlobalConstant.userRoles.get(userType));

        return new Response(ResponseCodes.success);
    }
    public Response forgetPassword(ForgetPasswordRequest request, String forgetPasswordToken){
        if(basicTokenUtil.isTokenExpired(forgetPasswordToken)){
            return new Response(ResponseCodes.EXPIRED_TOKEN);
        }
        Claims claims = basicTokenUtil.getAllClaimsFromToken(forgetPasswordToken);
        boolean validated = (boolean) claims.get("validated");
        int serviceId = (int) claims.get("serviceId");
        int userType = (int) claims.get("userType");
        if(!validated || serviceId != GlobalConstant.FORGET_PASSWORD){
            return new OtpResponse(ResponseCodes.INVALID_TOKEN_INFO);
        }
        String password = request.getNewPassword();
        String nid = (String) claims.get("userName");
        if(nid==null || !NATIONAL_ID_VALIDATION.test(nid)){
            return new Response(ResponseCodes.INVALID_NATIONAL_ID);
        }
        if(password == null || password.length() < 6){
            return new Response(ResponseCodes.INVALID_PASSWORD);
        }

        int roleID = GlobalConstant.userRoles.get(userType);
        AuthUser user = getUserByUsernameAndRoleID(nid,roleID);
        if(user==null)
            return new Response(ResponseCodes.USER_NOT_FOUND);

        user.setPassword(request.getNewPassword());
        userRepository.save(user);

        return new Response(ResponseCodes.success);
    }
    private void saveUser(long userType, String nid, String password, int roleID){
        AuthService authService = serviceRepository.findAuthServiceById(userType);
        AuthRole role = roleRepository.findAuthRoleById((short) roleID);
        AuthUser user = new AuthUser();
        user.setEnabled(true);
        user.setPassword(password);
        user.setUsername(nid);
        user.setAuthServiceList(Collections.singletonList(authService));
        user.setRole(role);
        userRepository.save(user);
    }
    private AuthUser getUserByUsernameAndRoleID(String userName,int roleID){
        AuthRole role = roleRepository.findAuthRoleById((short) roleID);
        return userRepository.findByUsernameAndRole(userName,role);
    }
}
