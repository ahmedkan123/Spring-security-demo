package com.app.services.validation;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.regex.Pattern;

public class SystemValidation {

    private static final List<String> NO_OF_DAYS_IN_MONTH = Arrays.asList("01", "02", "03", "04", "05", "06",
            "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
            "22", "23", "24", "25", "26", "27", "28", "29", "30", "31");

    private static final List<String> NO_OF_MONTH = Arrays.asList("01", "02", "03", "04", "05", "06", "07", "08",
            "09", "10", "11", "12");

    private static final List<String> GOVERNORATE_CODE_IN_NATIONAL_ID = Arrays.asList("01", "02", "03", "04",
            "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21",
            "22", "23", "24", "25", "26", "27", "28", "29");

    private static final List<String> NATIONAL_ID_START_NO = Arrays.asList("1", "2", "3", "4");


    /**
     * validation
     * is arabic language
     */
    public static final Predicate<String> IS_ARABIC_VALID = Pattern.compile("^[\\u0621-\\u064A0-9 ]+$",
            Pattern.CASE_INSENSITIVE).asPredicate();

    /**
     * validation
     * is email address
     */
    public static final Predicate<String> IS_EMAIL_VALID = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
            Pattern.CASE_INSENSITIVE).asPredicate();

    /**
     * validation
     * is national id
     */
    public static Predicate<String> NATIONAL_ID_VALIDATION = (String nationId) -> {
        nationId = nationId.trim();
        if(nationId.length() != 14)
            return false;

        for (char c : nationId.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        final String START_NO = nationId.substring(0, 1);
        final String YEAR = nationId.substring(1, 3);
        final String MONTH = nationId.substring(3, 5);
        final String DAY = nationId.substring(5, 7);
        final String GOVERNORATE_CODE = nationId.substring(7, 9);
        boolean status = false;
        if (NATIONAL_ID_START_NO.contains(START_NO)
                && NO_OF_MONTH.contains(MONTH)
                && NO_OF_DAYS_IN_MONTH.contains(DAY)
                && GOVERNORATE_CODE_IN_NATIONAL_ID.contains(GOVERNORATE_CODE)
                && nationId.length() == 14) {
                    status = true;
        }
        return status;
    };

    public static Predicate<String> NUMBER_VALIDATION = seatNumber -> {
        seatNumber = seatNumber.trim();
        boolean status = false;
        for (char c : seatNumber.toCharArray()) {
            if (!Character.isDigit(c))
                status = false;
            else
                status = true;
        }
        return status;
    };

    public static Predicate<String> IS_MOBILE_NUMBER = mobileNumber -> {
        mobileNumber = mobileNumber.trim();
        boolean status = false;
        for (char c : mobileNumber.toCharArray()) {
            if (!Character.isDigit(c))
                return false;

        }

        if(mobileNumber.length() != 11)
            return false;

        if(mobileNumber.startsWith("010") || mobileNumber.startsWith("012")
            || mobileNumber.startsWith("011") || mobileNumber.startsWith("015"))
            status = true;

        return status;
    };
}
